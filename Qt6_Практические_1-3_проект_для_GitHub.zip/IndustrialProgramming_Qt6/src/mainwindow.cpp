#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QString>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->comboBox_base->addItem("Десятичная (10)");
    ui->comboBox_base->addItem("Двоичная (2)");
    ui->comboBox_base->addItem("Восьмеричная (8)");
    ui->comboBox_base->addItem("Шестнадцатеричная (16)");
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_sum_clicked()
{
    bool correct1 = false;
    bool correct2 = false;

    int base = 10;
    switch (ui->comboBox_base->currentIndex()) {
    case 0: base = 10; break;
    case 1: base = 2;  break;
    case 2: base = 8;  break;
    case 3: base = 16; break;
    }

    QString text1 = ui->lineEdit_value_1->text().trimmed();
    QString text2 = ui->lineEdit_value_2->text().trimmed();

    int value1 = text1.toInt(&correct1, base);
    int value2 = text2.toInt(&correct2, base);

    if (correct1 && correct2) {
        int sum = value1 + value2;
        ui->label_result_value->setText(QString::number(sum, base).toUpper());
    } else {
        ui->label_result_value->setText(
            "Ошибка: проверьте числа и выбранную систему");
    }
}
